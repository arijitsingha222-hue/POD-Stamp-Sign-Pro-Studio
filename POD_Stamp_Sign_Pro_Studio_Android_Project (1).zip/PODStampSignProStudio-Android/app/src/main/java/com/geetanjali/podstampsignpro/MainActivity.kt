package com.geetanjali.podstampsignpro

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerRequest = 4102

    inner class AndroidDownloader(private val ctx: Context) {
        @JavascriptInterface
        fun saveFile(dataUrl: String, fileName: String, mimeType: String) {
            try {
                val base64Data = if (dataUrl.contains(",")) dataUrl.substringAfter(",") else dataUrl
                val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                val safeName = if (fileName.isBlank()) "POD_Stamped_${System.currentTimeMillis()}.jpg" else fileName
                val resolvedMime = when {
                    safeName.endsWith(".pdf", true) -> "application/pdf"
                    safeName.endsWith(".png", true) -> "image/png"
                    else -> if (mimeType.isBlank()) "image/jpeg" else mimeType
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, resolvedMime)
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val resolver = ctx.contentResolver
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) {
                        resolver.openOutputStream(uri)?.use { it.write(bytes) }
                        values.clear()
                        values.put(MediaStore.Downloads.IS_PENDING, 0)
                        resolver.update(uri, values, null, null)
                    }
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (!dir.exists()) dir.mkdirs()
                    val outFile = File(dir, safeName)
                    FileOutputStream(outFile).use { it.write(bytes) }
                    MediaScannerConnection.scanFile(ctx, arrayOf(outFile.absolutePath), arrayOf(resolvedMime), null)
                }

                runOnUiThread {
                    Toast.makeText(ctx, "Saved to Downloads: $safeName", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(ctx, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = FrameLayout(this).apply {
            fitsSystemWindows = true
        }
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportZoom(true)
            builtInZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        webView.addJavascriptInterface(AndroidDownloader(this), "AndroidDownloader")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
                }
                return try {
                    startActivityForResult(Intent.createChooser(intent, "Select POD Image or PDF"), filePickerRequest)
                    true
                } catch (_: ActivityNotFoundException) {
                    filePathCallback = null
                    Toast.makeText(this@MainActivity, "No file manager found", Toast.LENGTH_SHORT).show()
                    false
                }
            }
        }
        webView.setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            val guessedName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            if (url.startsWith("data:")) {
                AndroidDownloader(this).saveFile(url, guessedName, mimeType ?: "image/jpeg")
            } else if (url.startsWith("blob:")) {
                val safeUrl = url.replace("'", "")
                val safeMime = (mimeType ?: "image/jpeg").replace("'", "")
                val js = "(function(){fetch('$safeUrl').then(r=>r.blob()).then(b=>{var rd=new FileReader();rd.onloadend=function(){AndroidDownloader.saveFile(rd.result,'POD_Stamped_'+Date.now()+'.jpg','$safeMime');};rd.readAsDataURL(b);});})();"
                webView.evaluateJavascript(js, null)
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
        container.addView(webView)
        setContentView(container)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == filePickerRequest) {
            val results: Array<Uri>? = when {
                resultCode != Activity.RESULT_OK || data == null -> null
                data.data != null -> arrayOf(data.data!!)
                data.clipData != null && data.clipData!!.itemCount > 0 -> arrayOf(data.clipData!!.getItemAt(0).uri)
                else -> null
            }
            filePathCallback?.onReceiveValue(results)
            filePathCallback = null
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        filePathCallback?.onReceiveValue(null)
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
