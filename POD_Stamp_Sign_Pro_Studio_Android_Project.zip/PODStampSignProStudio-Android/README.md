# POD Stamp & Sign Pro Studio — Android project

This project wraps the supplied HTML app in an Android WebView and uses the supplied POD Stamp & Sign logo as the launcher icon.

## Build an APK with Android Studio
1. Install Android Studio on Windows.
2. Extract this ZIP.
3. Open the `PODStampSignProStudio` folder in Android Studio.
4. Allow Gradle sync and install Android SDK Platform 35 if prompted.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio will show the APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

## Important
- This is a WebView wrapper around your uploaded HTML; the HTML tool logic is retained.
- The HTML currently loads Tailwind CSS, Google Fonts, PDF.js and jsPDF from external CDNs. Therefore internet is required for those CDN-based features unless the libraries are bundled locally.
- File selection and downloads are handled by the Android wrapper.
- This workspace did not have the Android SDK / Gradle installed, so a compiled APK could not be produced or tested here.
